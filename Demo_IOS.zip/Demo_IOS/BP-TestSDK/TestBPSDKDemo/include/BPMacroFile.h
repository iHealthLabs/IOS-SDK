//
//  BPMacroFile.h
//  BP_SDKDemo
//
//  Created by zhiwei jing on 14-2-25.
//  Copyright (c) 2014年 zhiwei jing. All rights reserved.
//

#ifndef BP_SDKDemo_BPMacroFile_h
#define BP_SDKDemo_BPMacroFile_h

typedef enum {
    BPNormalError = 1,//device error, error message displayed automatically
    BPOverTimeError,//Abnormal communication
    BPNoRespondError,//Abnormal communication
    BPBeyondRangeError,//device is out of communication range.
    BPDidDisconnect,//device is disconnected.
    BPAskToStopMeasure//measurement has been stopped.
    
}BPDeviceError;

typedef enum{
    UserAuthen_RegisterSuccess = 1,//New-user registration succeeded
    UserAuthen_LoginSuccess,// User login succeeded
    UserAuthen_CombinedSuccess,// The user is iHealth user as well, measurement via SDK has been activated, and the data from the measurement belongs to the user
    UserAuthen_TrySuccess,//Testing without Internet connection succeeded
    UserAuthen_InvalidateUserInfo,//Userid/clientID/clientSecret verification failed
    UserAuthen_SDKInvalidateRight,//SDK has not been authorized
    UserAuthen_UserInvalidateRight,//User has not been authorized
    UserAuthen_InternetError//Internet error, verification failed
}UserAuthenResult;

typedef void (^BlockEnergyValue)(NSNumber *energyValue);
typedef void(^BlockError)(BPDeviceError error);
typedef void(^BlockDeviceFounction)(NSDictionary *dic);
typedef void(^BlockBlueSet)(BOOL isOpen);
typedef void(^BlockAngle)(NSDictionary *dic);
typedef void(^BlockPressure)(NSArray *pressureArr);
typedef void(^BlockXioaboWithHeart)(NSArray *xiaoboArr);
typedef void(^BlockXioaboNoHeart)(NSArray *xiaoboArr);
typedef void(^BlockZero)(BOOL isComplete);
typedef void(^BlockMesureResult)(NSDictionary *dic);

typedef void(^BlockBachCount)(NSNumber *num);
typedef void(^BlockBachProgress)(NSNumber *pregress);
typedef void(^BlockBachArray)(NSArray *array);

typedef void(^BlockStopSuccess)();

typedef void (^BlockUserAuthentication)(UserAuthenResult result);//the result of userID verification

typedef void(^BlockStopResult)(BOOL result);
typedef void(^BlockDelPortResult)(BOOL result);


#define BP3ConnectNoti @"BP3ConnectNoti"
#define BP3DisConnectNoti @"BP3DisConnectNoti"
#define BP5ConnectNoti @"BP5ConnectNoti"
#define BP5DisConnectNoti @"BP5DisConnectNoti"
#define BP7ConnectNoti @"BP7ConnectNoti"
#define BP7DisConnectNoti @"BP7DisConnectNoti"

#define BPDeviceID @"ID"
#define BPSDKRightApi  @"OpenApiBP"

#endif
