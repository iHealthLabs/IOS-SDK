//
//  AppDelegate.h
//  TestBPSDKDemo
//
//  Created by zhiwei jing on 14-2-26.
//  Copyright (c) 2014年 zhiwei jing. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
