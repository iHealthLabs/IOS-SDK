//
//  ViewController.h
//  TestBPSDKDemo
//
//  Created by zhiwei jing on 14-2-26.
//  Copyright (c) 2014年 zhiwei jing. All rights reserved.
//

#import <UIKit/UIKit.h>


#warning ‘SDKKey’ and ‘SDKSecret’ are the only identification for user of SDK, are required registration from iHealth administrator
#define SDKKey  @""
#define SDKSecret  @""

#warning ‘userID’, the only identification for the user，by the form of email or cell phone #(cell-phone-# form is not supported temperately)
#define UserID @""

@interface ViewController : UIViewController

@property (weak, nonatomic) IBOutlet UITextView *tipTextView;
@end
