//
//  BPViewController.h
//  iHealthDemoCode
//
//  Created by zhiwei jing on 14-9-23.
//  Copyright (c) 2014年 zhiwei jing. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface BPViewController : UIViewController

@property (weak, nonatomic) IBOutlet UITextView *tipTextView;

@end
