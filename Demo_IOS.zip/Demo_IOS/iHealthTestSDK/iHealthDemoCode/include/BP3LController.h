//
//  BP3LViewController.h
//  testShareCommunication
//
//  Created by my on 14/10/13.
//  Copyright (c) 2013年 my. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BP3LController : NSObject{
    NSMutableArray *BP3LDeviceArray;
}

+(BP3LController *)shareBP3LController;

//Get all bp instance
-(NSArray *)getAllCurrentBP3LInstace;

//Restart search BP3L
-(void)startSearchBP3L;

//Stop search BP3L
-(void)stopSearchBP3L;

@end
