//
//  HTMacroFile.h
//  HT_SDKDemo
//
//  Created by zhiwei jing on 14-2-25.
//  Copyright (c) 2014年 zhiwei jing. All rights reserved.
//


#ifndef HT_SDKDemo_HTMacroFile_h
#define HT_SDKDemo_HTMacroFile_h

#import "User.h"

#define HTSConnectNoti @"HTSConnectNoti"
#define HTSDisConnectNoti @"HTSDisConnectNoti"




#endif
