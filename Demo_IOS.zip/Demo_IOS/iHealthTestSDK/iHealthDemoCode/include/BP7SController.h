//
//  BP7SController.h
//  testShareCommunication
//
//  Created by my on 8/10/13.
//  Copyright (c) 2013年 my. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BP7SController : NSObject{
    NSMutableArray *BP7SDeviceArray;
}

+(BP7SController *)shareBP7SController;

//Get all bp instance
-(NSArray *)getAllCurrentBP7SInstace;

//Restart search BP7S
-(void)startSearchBP7S;

//Stop search BP7S
-(void)stopSearchBP7S;



@end
