//
//  POViewController.h
//  iHealthDemoCode
//
//  Created by zhiwei jing on 14-9-23.
//  Copyright (c) 2014年 zhiwei jing. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface POViewController : UIViewController

@property (weak, nonatomic) IBOutlet UITextView *tipTextView;


- (IBAction)ScanPO3:(id)sender;


@end
