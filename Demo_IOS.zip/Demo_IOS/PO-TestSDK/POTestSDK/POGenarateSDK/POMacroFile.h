//
//  POMacroFile.h
//  POSDK
//
//  Created by 小翼 on 14-8-11.
//  Copyright (c) 2014年 hejiasu. All rights reserved.
//

#ifndef POSDK_POMacroFile_h
#define POSDK_POMacroFile_h

#define PO3DeviceID @"ID"
#define PO3SDKRightApi  @"OpenApiSpO2"

typedef enum{
    UserAuthen_RegisterSuccess = 1,//New-user registration succeeded
    UserAuthen_LoginSuccess,// User login succeeded
    UserAuthen_CombinedSuccess,// The user is iHealth user as well, measurement via SDK has been activated, and the data from the measurement belongs to the user
    UserAuthen_TrySuccess,//Testing without Internet connection succeeded
    UserAuthen_InvalidateUserInfo,//Userid/clientID/clientSecret verification failed
    UserAuthen_SDKInvalidateRight,//SDK has not been authorized
    UserAuthen_UserInvalidateRight,//User has not been authorized
    UserAuthen_InternetError//Internet error, verification failed
}UserAuthenResult;

typedef enum{
    PO3CommError = 0,// Bluetooth Communication Error
    PO3AccessError,  // Flash (Data) Access Error
    PO3HardwareError, // Irregular Hardware Error
    PO3PRbpmtestError,//// The SpO2 or pulse rate test result is beyond the measurement range of the system
    PO3UnknownError,// Unknown Interference Detected
    PO3SendCommandFaild,// Send failed
    PO3DeviceDisConect,// Device is disconnected
    PO3DataZero,// No data
    PO3UserInvalidate = 111//// User authentication fails
    
}PO3ErrorID;



typedef void (^BlockUserAuthentication)(UserAuthenResult result);//the result of userID verification

#define PO3ConnectNoti @"PO3ConnectNoti"
#define PO3DisConnectNoti @"PO3DisConnectNoti"

#endif
