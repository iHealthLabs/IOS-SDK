//
//  PO3Controller.h
//  testShareCommunication
//
//  Created by daiqingquan on 13-11-29.
//  Copyright (c) 2013年 my. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface PO3Controller : NSObject{
    
    NSMutableArray *PO3Array;
}

+(PO3Controller *)shareIHPO3Controller;

//Get all scale instance,use PO3Instance to call PO3 related communication methods.
-(NSArray *)getAllCurrentPO3Instace;


@end
