//
//  PO3ViewController.m
//  POSDK
//
//  Created by 小翼 on 14-8-13.
//  Copyright (c) 2014年 hejiasu. All rights reserved.
//

#import "PO3ViewController.h"
#import "POHeader.h"

#warning ‘SDKKey’ and ‘SDKSecret’ are the only identification for user of SDK, are required registration from iHealth administrator
#define SDKKey  @""
#define SDKSecret  @""

#warning ‘YourUserName’, the only identification for the user，by the form of email or cell phone #(cell-phone-# form is not supported temperately)
#define YourUserName @""
@interface PO3ViewController ()

@end

@implementation PO3ViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(DeviceConnectForPO3:) name:PO3ConnectNoti object:nil];
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(DeviceDisConnectForPO3:) name:PO3DisConnectNoti object:nil];
    [PO3Controller shareIHPO3Controller];
    
    
    
}

-(void)DeviceDisConnectForPO3:(NSNotification*)info
{
    
}



-(void)DeviceConnectForPO3:(NSNotification*)info
{
    PO3Controller *po3Controller = [PO3Controller shareIHPO3Controller];
    NSArray *po3Array = [po3Controller getAllCurrentPO3Instace];
    
    if(po3Array.count>0)
    {
        PO3 *po3Instance = [po3Array objectAtIndex:0];
        User *myUser = [[User alloc]init];
        
        myUser.clientID = SDKKey;
        myUser.clientSecret = SDKSecret;
        myUser.userID = YourUserName;
        

        [po3Instance commandCreatePO3User:myUser Authentication:^(UserAuthenResult result) {
            NSLog(@"UserAuthenResult---%d",result);
            
        } DisposeResultBlock:^(BOOL finishSynchronous) {
            NSLog(@"finishSynchronous---%d",finishSynchronous);
            
        } DisposeErrorBlock:^(PO3ErrorID errorID) {
            NSLog(@"errorID---%d",errorID);
            
        }];

    }
}



- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)ScanPO3:(UIButton*)sender {
    
    PO3Controller *po3Controller = [PO3Controller shareIHPO3Controller];
    NSArray *po3Array = [po3Controller getAllCurrentPO3Instace];
    User *myUser = [[User alloc]init];
    
    PO3 *po3Instance;
    if(po3Array.count>0)
    {
        po3Instance = [po3Array objectAtIndex:0];
        
        myUser.clientID = SDKKey;
        myUser.clientSecret = SDKSecret;
        myUser.userID = YourUserName;
    }
    
    
    switch (sender.tag)
    {
        case 0:
        {
            NSLog(@"OnLineData");
            [po3Instance commandStartPO3MeasureData:^(BOOL startData) {
                NSLog(@"startData---%d",startData);

            } Measure:^(NSDictionary *measureDataDic) {
                NSLog(@"measureDataDic---%@",measureDataDic);

            } FinishPO3MeasureData:^(BOOL finishData) {
                NSLog(@"finishData---%d",finishData);

            } DisposeErrorBlock:^(PO3ErrorID errorID) {
                NSLog(@"errorID---%d",errorID);

            }];
        }
            break;
        case 1:
        {
            NSLog(@"offLineData");

            [po3Instance commandDisposePO3DataCount:^(NSNumber *dataCount) {
                NSLog(@"dataCount---%d",[dataCount intValue]);
                
            } TransferMemorryData:^(BOOL startData) {
                NSLog(@"startData---%d",startData);
                
            } Memory:^(NSDictionary *historyDataDic) {
                NSLog(@"historyDataDic---%@",historyDataDic);
                
            } DisposePO3WaveHistoryData:^(NSDictionary *waveHistoryDataDic) {
                NSLog(@"waveHistoryDataDic---%@",waveHistoryDataDic);
                
            } DisposeProgress:^(NSNumber *progress) {
                NSLog(@"progress---%@",progress);
                
            } FinishTransmission:^(BOOL finishData) {
                NSLog(@"finishData---%d",finishData);
                
            } DisposeErrorBlock:^(PO3ErrorID errorID) {
                NSLog(@"errorID---%d",errorID);
                
            }];
            
        }
            break;
            case 2:
        {
            NSLog(@"Electricity");

            [po3Instance commandQueryBatteryInfo:^(BOOL resetSuc) {
                NSLog(@"resetSuc---%d",resetSuc);

            } DisposeErrorBlock:^(PO3ErrorID errorID) {
                NSLog(@"errorID---%d",errorID);

            } DisposeBattery:^(NSNumber *battery) {
                NSLog(@"battery---%d",battery.intValue);

            }];
        }
            break;
            case 3:
        {
            NSLog(@"Restore factory settings");
            [po3Instance commandResetPO3DeviceDisposeResultBlock:^(BOOL resetSuc) {
                NSLog(@"resetSuc---%d",resetSuc);

            } DisposeErrorBlock:^(PO3ErrorID errorID) {
                NSLog(@"errorID---%d",errorID);

            }];
        }
            break;
            case 4:
        {
            NSLog(@"disConnect");
            
            [po3Instance commandEndPO3CurrentConnect:^(BOOL resetSuc) {
                NSLog(@"resetSuc---%d",resetSuc);
                
            } DisposeErrorBlock:^(PO3ErrorID errorID) {
                NSLog(@"errorID---%d",errorID);
                
            }];
        }
            break;
        
        default:
            break;
    }
    

 
}

@end
