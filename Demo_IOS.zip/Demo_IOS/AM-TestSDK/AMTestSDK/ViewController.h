//
//  ViewController.h
//  AMTestSDK
//
//  Created by zhiwei jing on 14-8-11.
//  Copyright (c) 2014年 zhiwei jing. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AMHeader.h"

#warning ‘SDKKey’ and ‘SDKSecret’ are the only identification for user of SDK, are required registration from iHealth administrator
#define SDKKey  @""
#define SDKSecret  @""

#warning ‘YourUserName’, the only identification for the user，by the form of email or cell phone #(cell-phone-# form is not supported temperately)
#define YourUserName @""



@interface ViewController : UIViewController{
    AM3 *tempAM3Instance;
    AM3S *tempAM3SInstance;
    NSInteger tempCloudUserSerialNub;
}
@property (weak, nonatomic) IBOutlet UITextField *randomTextField;

- (IBAction)AM3_ClockQuery:(id)sender;
- (IBAction)AM3_ReminderQuery:(id)sender;
- (IBAction)AM3_Reset:(id)sender;

- (IBAction)AM3S_BinedUser:(id)sender;
- (IBAction)AM3S_ClockQuery:(id)sender;
- (IBAction)AM3S_ReminderQuery:(id)sender;
- (IBAction)AM3S_Reset:(id)sender;
- (IBAction)touchBackgroundPressed:(id)sender;
@end
