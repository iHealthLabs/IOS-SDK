//
//  User.h
//  AMDemoCode
//
//  Created by zhiwei jing on 14-8-12.
//  Copyright (c) 2014年 zhiwei jing. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AMMacroFile.h"

@interface User : NSObject

@property (nonatomic, strong) NSString * clientID;
@property (nonatomic, strong) NSString * clientSecret;
@property (nonatomic, strong) NSString * userID;


@property (strong, nonatomic)NSDate *birthday;
@property UserSex sex;
@property LengthUnit lengthUnit;
@property (strong, nonatomic)NSNumber *height;
@property (strong, nonatomic)NSNumber *weight;
@property (strong, nonatomic)NSNumber *bmr;

@end
