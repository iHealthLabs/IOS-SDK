//
//  User.h
//  HSDemoCode
//
//  Created by zhiwei jing on 14-7-23.
//  Copyright (c) 2014年 zhiwei jing. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "HSMacroFile.h"

@interface User : NSObject

@property (nonatomic, strong) NSString * clientID;
@property (nonatomic, strong) NSString * clientSecret;
@property (nonatomic, strong) NSString * userID;

@property (nonatomic, strong) NSNumber * serialNub;
@property (nonatomic, strong) NSDate *birthday;
//unit:cm
@property (nonatomic, strong) NSNumber * height;
@property UserIsAthelete isAthlete;
@property UserSex sex;


@end
