//
//  ViewController.h
//  HSTestSDK
//
//  Created by zhiwei jing on 14-7-23.
//  Copyright (c) 2014年 zhiwei jing. All rights reserved.
//

#import <UIKit/UIKit.h>

#warning ‘SDKKey’ and ‘SDKSecret’ are the only identification for user of SDK, are required registration from iHealth administrator
#define SDKKey  @""
#define SDKSecret  @""

#warning ‘YourUserName’, the only identification for the user，by the form of email or cell phone #(cell-phone-# form is not supported temperately)
#define YourUserName @""

@class User;

@interface ViewController : UIViewController{
    
    User *currentUser;
}

- (IBAction)commandUploadHS4MemoryPressed:(id)sender;
- (IBAction)commandUploadHS5MemoryPressed:(id)sender;
- (IBAction)commandDataCloud:(id)sender;


@end
