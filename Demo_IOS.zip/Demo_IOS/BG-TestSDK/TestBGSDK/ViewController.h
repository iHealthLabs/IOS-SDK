//
//  ViewController.h
//  TestBGSDK
//
//  Created by zhiwei jing on 14-7-2.
//  Copyright (c) 2014年 zhiwei jing. All rights reserved.
//

#import <UIKit/UIKit.h>

#warning ‘SDKKey’ and ‘SDKSecret’ are the only identification for user of SDK, are required registration from iHealth administrator
#define SDKKey  @""
#define SDKSecret  @""

#warning ‘CodeStr’, gets the code information by scanning the QR code
#define CodeStr @""

#warning ‘YourUserName’, the only identification for the user，by the form of email or cell phone #(cell-phone-# form is not supported temperately)
#define YourUserName @""

@interface ViewController : UIViewController

@property (weak, nonatomic) IBOutlet UITextView *tipTextView;

- (IBAction)getBG5Memory:(id)sender;

@end
